<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

Este projeto é um portfólio Next.js com Tailwind CSS. Gere componentes modernos, responsivos e otimizados para performance.
